/* eslint-disable jsx-a11y/alt-text */
import React, { useEffect, useState, useRef } from "react";
import { connect } from "react-redux";

const Home = (props) => {
  return (
    <div>
      This is home
    </div>
  );
};
const mapStateToProps = (state) => {
  return {
  };
};

export default connect(mapStateToProps, {
})(Home);
