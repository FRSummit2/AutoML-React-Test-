/* eslint-disable jsx-a11y/alt-text */
import React, { useEffect, useState, useRef } from "react";
import { connect } from "react-redux";

const Login = (props) => {
  return (
    <div>
      This is Login
    </div>
  );
};
const mapStateToProps = (state) => {
  return {
  };
};

export default connect(mapStateToProps, {
})(Login);
